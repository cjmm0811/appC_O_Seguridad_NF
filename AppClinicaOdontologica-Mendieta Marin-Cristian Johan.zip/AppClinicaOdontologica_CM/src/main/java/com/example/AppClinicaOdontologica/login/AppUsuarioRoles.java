package com.example.AppClinicaOdontologica.login;

public enum AppUsuarioRoles {
    USER, ADMIN
}
